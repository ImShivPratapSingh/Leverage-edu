const url = ""; // excel sheet url

const resume_link = ""; // resume link

const auth = {
  user: "", // email id
  pass: "", //password
};

module.exports = { url, auth, resume_link };
