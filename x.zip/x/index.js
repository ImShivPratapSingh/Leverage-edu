const xlsx = require("xlsx");
const nodemailer = require("nodemailer");
const { exit } = require("process");
const axios = require("axios");
const { getReferralHTML } = require("./text");
const { url, auth } = require("./data");

const transporter = nodemailer.createTransport({
  pool: true,
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth,
});

// Send a single email
const sendEmail = async (row) => {
  const { Name, Company, Email, Role, Link } = row;
  const name = Name?.split(" ")[0];

  const mailOptions = {
    from: `"Mansi Singla" <mansisingla802@gmail.com>`,
    to: Email,
    subject: `Request for an Interview Opportunity - ${Role} at ${Company}`,
    html: getReferralHTML(name, Company, Role, Link),
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("✅ Email sent to", Email);
  } catch (error) {
    console.error("❌ Error sending email to", Email, error.message);
  }
};

// Send emails sequentially
const sendEmailsSynchronously = async (rows, sheetName) => {
  for (const row of rows) {
    await sendEmail(row);
    await new Promise(
      (resolve) => setTimeout(resolve, 30000 + Math.random() * 60000) // 30–90 sec delay
    );
  }
  console.log(`🎯 Done Sending mails for ${sheetName}`);
  exit();
};

// Function to fetch remote Excel and process
const fetchRemoteExcel = async (sheetName, show_console) => {
  if (!sheetName) return;
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    const workbook = xlsx.read(res.data, { type: "buffer" });
    const sheet = workbook.Sheets[sheetName];
    const remoteData = xlsx.utils.sheet_to_json(sheet);

    if (show_console) console.log(remoteData);
    else return remoteData;
  } catch (error) {
    console.error("❌ Error fetching/parsing remote Excel:", error.message);
    return [];
  }
};

// To send from remote file:
const sheetName = "JioStar";
// fetchRemoteExcel(sheetName, true);
fetchRemoteExcel(sheetName).then((rows) =>
  sendEmailsSynchronously(rows, sheetName)
);
