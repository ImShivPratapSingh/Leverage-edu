const { resume_link } = require("./data");

const getReferralHTML = (name = "", company = "", role = "", link) => {
  return `
      <div style="font-family: Calibri, Arial, sans-serif; font-size: 15px; line-height: 1.6; color: #333;">
      <p>Greetings ${name},</p>
      
      <p>I'm Mansi Singla, a Software Development Engineer at 
          <a href="https://wizcommerce.com/" style="color:#0066cc; text-decoration:none;">WizCommerce</a>. 
          I came across a post about <b>${company}</b> looking for a <b>${role}</b> and wanted to introduce myself. I have:</p>
      
     <ul style="margin-top:0; margin-bottom:1em; padding-left:20px;">
      <li><b>2+ years</b> experience as <b>Software Development Engineer - Frontend</b> at WizCommerce, delivering features that drove <b>200%+ customer growth</b> and enabled <b>$5M+ in monthly transactions</b>.</li>
      <li>Hands-on expertise in <b>JavaScript, TypeScript, React.js, Redux, Node.js, Express.js</b>.</li>
      <li><b>1 year</b> experience as <b>Associate Software Engineer</b> at MAQ Software, creating <b>60+ data migration pipelines</b> and optimizing backend reporting systems used by <b>1,000+ users</b> for clients like <b>Microsoft</b> and <b>PepsiCo</b>.</li>
  </ul>
      
      <p>PS: I have attached my <b>
          <a href="${resume_link}" style="color:#0066cc; text-decoration:none;">Resume</a></b>, 
          <b><a href="https://www.linkedin.com/in/mansi-singla/" style="color:#0066cc; text-decoration:none;">LinkedIn</a></b>
          ${
            link
              ? `and <b><a href="${link}" style="color:#0066cc; text-decoration:none;">${role}</a></b> Opening`
              : ""
          }
      </p>
      
      <p>Thanking You,<br>
      Regards,<br>
      Mansi Singla<br>
      Contact No: +91 9468145495<br>
      Email: <a href="mailto:mansisingla802@gmail.com" style="color:#0066cc; text-decoration:none;">mansisingla802@gmail.com</a></p>
  </div>
  
    `;
};

const getLinkedInReferralText = (name, company, role, link) => {
  return `
Hi ${name},

Mansi this side. How are you doing?

I recently came across an exciting opportunity for a ${role} position at ${company}, and I believe it aligns perfectly with my skills and experience. I would really appreciate it if you could help push my application forward for this opportunity, if possible :)

${
  link
    ? `Job Link
${link}`
    : ""
}

${
  resume_link
    ? `Resume 
${resume_link}`
    : ""
}
  `;
};

const getCutShortText = (name, company, role, link) => {
  return `
  Greetings ${name},
  
  I'm Mansi Singla, a Software Development Engineer at WizCommerce (https://wizcommerce.com/). I came across your post about ${company} looking for a ${role} and wanted to introduce myself. I have:
  
  2+ years experience as Software Development Engineer - Frontend at WizCommerce, delivering features that drove 200%+ customer growth and enabled $5M+ in monthly transactions.
  
  Hands-on expertise in JavaScript, TypeScript, React.js, Redux, Node.js, Express.js.
  
  1 year experience as Associate Software Engineer at MAQ Software, creating 60+ data migration pipelines and optimizing backend reporting systems used by 1,000+ users for clients like Microsoft and PepsiCo.
  
  PS: I have attached my Resume (${resume_link}) and LinkedIn (https://www.linkedin.com/in/mansi-singla/)${
    link ? ` and ${role} Opening (${link})` : ""
  }.
  
  Thanking You,
  Regards,
  Mansi Singla
  Contact No: +91 9468145495
  Email: mansisingla802@gmail.com
    `;
};

const getFollowUpText = (name, company, role) => {
  return `
Greetings ${name},

I hope you're doing well.

I wanted to express my sincere gratitude for the opportunity to
interview for the ${role} role at ${company}. It was a pleasure
discussing how my skills and experiences align with the team’s needs
and the company’s vision.

I wanted to follow up on the status of the hiring process and inquire
about any next steps. Please let me know if there is any additional
information or documentation you need from me at this stage.

Thank you again for considering my application. I look forward to
hearing from you soon.

Best regards,
Mansi Singla
  `;
};

module.exports = {
  getReferralHTML,
  getCutShortText,
  getLinkedInReferralText,
  getFollowUpText,
};

// <p>Currently, I am <b>serving my notice period</b> and can <b>join within 30 days</b>.</p>
