# My Node.js Package

A simple Node.js package with basic utility functions.

## Installation

```bash
npm install
```

## Usage

### As a module

```javascript
const myPackage = require('./index.js');

console.log(myPackage.greet('Alice')); // Hello, Alice!
console.log(myPackage.add(5, 3));      // 8
console.log(myPackage.multiply(4, 6)); // 24
```

### Run directly

```bash
npm start
# or
node index.js
```

## API

### `greet(name)`
Returns a greeting message.
- `name` (string, optional): Name to greet. Defaults to 'World'.

### `add(a, b)`
Adds two numbers.
- `a` (number): First number
- `b` (number): Second number

### `multiply(a, b)`
Multiplies two numbers.
- `a` (number): First number
- `b` (number): Second number

## License

MIT
