const {
  getCutShortText,
  getFollowUpText,
  getLinkedInReferralText,
} = require("./text");

// const message = getCutShortText(
//   "Sharat",
//   "Inncircles",
//   "Senior Fullstack Product Developer"
// );

// const message = getFollowUpText("Ranvir", "Inkle", "Frontend Developer");

const message = getLinkedInReferralText(
  "Naman",
  "JPMorganChase",
  "Software Engineer II (Front End UI React Developer)",
  "https://www.linkedin.com/jobs/view/4285897189"
);

console.log(message);
